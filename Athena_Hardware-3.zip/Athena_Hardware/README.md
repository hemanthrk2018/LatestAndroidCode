# Athena Web

Athena Web is the current (and inaccurate) name for the embedded software running on the Athena Device.

## Reason for Current Name

The current name is based on the original intention for the software to occasionally run a webserver that the Mobile Athena app would access. It was later learned, however, that firewall rules would prevent such a mode of operation. Now, instead, the Mobile Athena app will run the web server, and this software will act as a web client. Suggested new name: Embedded Athena.

## Technologies in Play

* Android
* Bluetooth LE ("BLE")
* Protobuf
* WiFi
* SQLite
* JNI (Java Native Interface)

## General Structure

* Athena (implements the "[Mediator][mediator]" Pattern)
  * BLE (implements "Colleague" in the "Mediator" Pattern)
  * LED (Colleague)
  * Sensor (Colleague)
  * Storage (Colleague)
  * Web Client (Colleague)

## Running on a Generic Android Phone

The app should run fine on a generic Android Phone. There is a UI in `res/layout/main_activity.xml` to simulate LEDs and show simple information. Since the app requests to run as a system user on the actual Athena device, you must remove that request for generic Android phones. To do so, ensure the top-level XML element in `AndroidManifest.xml` looks as follows:

```xml
<manifest
  xmlns:android="http://schemas.android.com/apk/res/android"
  xmlns:tools="http://schemas.android.com/tools"
  package="com.jci.athena.sensor"
  >
```

Run the application from Android Studio.

## Running on a prototype Athena device

The app should run fine on a prototype Athena device as well, though it's a little more difficult to debug, since there's no screen. Furthermore, you need to have the app request to run as a system user (in order to toggle LEDS, among other things). To do that, ensure the top-level XML element in `AndroidManifest.xml` looks as follows:

```xml
<manifest
  xmlns:android="http://schemas.android.com/apk/res/android"
  xmlns:tools="http://schemas.android.com/tools"
  package="com.jci.athena.sensor"
  coreApp="true"
  android:sharedUserId="android.uid.system"
  >
```

The only difference should be `coreApp` and `android:sharedUserId`. It would be good to be able to automatically switch between these declarations based on the compilation target, but this has not yet been explored.



[mediator]: http://www.dofactory.com/net/mediator-design-pattern
