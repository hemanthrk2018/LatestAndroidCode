#include "athena-interop.hh"

#define RUNNING_ON_ACTUAL_DEVICE true

#if RUNNING_ON_ACTUAL_DEVICE
#include "ad7768.h"
#else
#include "fake-sensor.hh"
#endif

#include <android/log.h>
#include <signal.h>


JavaVM *g_javaVM;
jobject g_bridge;
jmethodID g_bridgeMethodID;
capture_option options;
volatile sig_atomic_t running = 0;


void my_sensor_callback(uint8_t *data, int data_length) {
    JNIEnv *env;
    if(g_javaVM->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return;
    }
    jbyteArray exportData = env->NewByteArray(data_length);
    env->SetByteArrayRegion(exportData, 0, data_length, reinterpret_cast<const jbyte *>(data));
    env->CallVoidMethod(g_bridge, g_bridgeMethodID, exportData);
    env->DeleteLocalRef(exportData);
}


jint JNI_OnLoad(JavaVM *vm, void *reserved){
    JNIEnv *env;
    g_javaVM = vm;
    if(vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return -1;
    }
    jclass g_clazz = env->FindClass("com/jci/athena/sensor/sensor/CppBridge");
    g_bridgeMethodID = env->GetMethodID(g_clazz, "callback", "([B)V");

    return JNI_VERSION_1_6;
}

JNIEXPORT jint JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_startCapture(JNIEnv *env, jobject thiz) {
    if (running == 1) return -1;
    g_bridge = env->NewGlobalRef(thiz);
    running = 1;
    capture_option *option = new capture_option();
    option->calibration = false;
    option->turbo = false;
    jint ret = start_capture(&my_sensor_callback, option);
    env->DeleteGlobalRef(g_bridge);
    return ret;
}


JNIEXPORT jint JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_sensorAvailable(JNIEnv *env, jobject thiz){
    jint ret = 0;
    if (running == 0){
        ret = sensor_available();
    }
    return ret;
}

JNIEXPORT jint JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_stopCapture(JNIEnv *env, jobject thiz) {

    if (running == 0) return -1;

    running = 0;
    stop_capture();
    //env->DeleteGlobalRef(g_bridge);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_turnOn( JNIEnv* env, jobject thiz) {
    turn_on();
}

JNIEXPORT void JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_turnOff( JNIEnv* env, jobject thiz) {
    turn_off();
}