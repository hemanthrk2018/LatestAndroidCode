//
// Created by Brad Grzesiak on 7/14/17.
//

#ifndef ATHENA_ATHENA_INTEROP_H
#define ATHENA_ATHENA_INTEROP_H

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif


JNIEXPORT jint JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_startCapture(JNIEnv *,
                                               jobject );

JNIEXPORT jint JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_stopCapture( JNIEnv* env, jobject thiz);

JNIEXPORT jint JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_sensorAvailable( JNIEnv* env, jobject thiz);

JNIEXPORT void JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_turnOn( JNIEnv* env, jobject thiz);

JNIEXPORT void JNICALL
Java_com_jci_athena_sensor_sensor_CppBridge_turnOff( JNIEnv* env, jobject thiz);

#ifdef __cplusplus
}
#endif


#endif //ATHENA_ATHENA_INTEROP_H
