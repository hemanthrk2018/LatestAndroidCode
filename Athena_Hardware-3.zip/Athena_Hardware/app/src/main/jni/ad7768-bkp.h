/*------------------------------------------------------------------------------
	(C) Copyright Johnson Controls, Inc. 2017
	Use or copying of all or any part of the document, except as
	permitted by the License Agreement is prohibited.

	Purpose:  File contains interface to get sensor data from CPDL
------------------------------------------------------------------------------*/

#ifndef _AD7768_H_
#define _AD7768_H_
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
Function: start_capture(void *(*sensor_callback)(uint8_t *, int));

Purpose:  This is a blocking call, please use a dedicated thread
          pass in a callback function to get the data
*******************************************************************************/
int start_capture(void (*sensor_callback)(uint8_t *, int));

/******************************************************************************
Function: stop_capture();

Purpose:  Notify the thread calling start_capture to finish and exit.
*******************************************************************************/
void stop_capture();
#ifdef __cplusplus
}
#endif
#endif /* _AD7768_H_ */
