
#include <stdint.h>

int start_capture(void (*sensor_callback)(uint8_t *, int));
void stop_capture();
