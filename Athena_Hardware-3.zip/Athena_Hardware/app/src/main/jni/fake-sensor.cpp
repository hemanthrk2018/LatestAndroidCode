#include <stdlib.h>
#include <unistd.h>

#include <android/log.h>


#define MIN_PACKET_SIZE 600
#define MAX_PACKET_SIZE 1000

volatile sig_atomic_t force_stop = 0;

int start_capture(void (*sensor_callback)(uint8_t *, int))
{
    int total = 0;
    uint8_t random_data[MAX_PACKET_SIZE];

    force_stop = 0;
    //__android_log_write(ANDROID_LOG_INFO, "JNI", "Up in here!");
    while(force_stop == 0) {
        //__android_log_write(ANDROID_LOG_INFO, "JNI Fake Sensor", "top of loop");

        // "8 samples +/- 2"
        int random_data_length = MIN_PACKET_SIZE +
            rand() % (MAX_PACKET_SIZE - MIN_PACKET_SIZE);

        for (int i = 0; i < MAX_PACKET_SIZE; i++) {
            random_data[i] = (uint8_t)(rand() % 256);
        }

        sensor_callback(random_data, random_data_length);

        total += random_data_length;

        sleep(1);
    }

    return total;
}

void stop_capture()
{
    force_stop = 1;
}
