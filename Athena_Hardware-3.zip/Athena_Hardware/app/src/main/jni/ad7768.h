/*------------------------------------------------------------------------------
	(C) Copyright Johnson Controls, Inc. 2017
	Use or copying of all or any part of the document, except as
	permitted by the License Agreement is prohibited.
	Purpose:  File contains interface to get sensor data from CPDL
------------------------------------------------------------------------------*/

#ifndef _AD7768_H_
#define _AD7768_H_
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

struct capture_option {
	bool turbo;
	bool calibration;
};

/******************************************************************************
Function: turn_on();
Purpose:  Initialization of ad7768 system
*******************************************************************************/
void turn_on();

/******************************************************************************
Function: sensor_available();
Purpose:  detect if the sensor has been attached
*******************************************************************************/
int sensor_available();

/******************************************************************************
Function: start_capture(void *(*sensor_callback)(uint8_t *, int));
Purpose:  This is a blocking call, please use a dedicated thread
          pass in a callback function to get the data
*******************************************************************************/
int start_capture(void (*sensor_callback)(uint8_t *, int), struct capture_option *option);

/******************************************************************************
Function: stop_capture();
Purpose:  Notify the thread calling start_capture to finish and exit.
*******************************************************************************/
void stop_capture();

/******************************************************************************
Function: turn_off();
Purpose:  shutdown ad7768 system
*******************************************************************************/
void turn_off();

#ifdef __cplusplus
}
#endif
#endif /* _AD7768_H_ */