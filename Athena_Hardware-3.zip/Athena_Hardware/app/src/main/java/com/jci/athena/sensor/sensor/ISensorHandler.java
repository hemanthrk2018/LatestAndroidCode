package com.jci.athena.sensor.sensor;

/**
 * Sensor Handler interface
 */

public interface ISensorHandler {
    void handleData(byte[] data);
    void setCaptureId(String captureId);
}
