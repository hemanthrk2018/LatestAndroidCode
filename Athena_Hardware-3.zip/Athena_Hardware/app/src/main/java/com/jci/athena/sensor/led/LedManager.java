package com.jci.athena.sensor.led;

import com.jci.athena.sensor.Colleague;
import com.jci.athena.sensor.Constants;
import com.jci.athena.sensor.Mediator;

import hugo.weaving.DebugLog;

/**
 * LED Manager class. Concrete colleague in the Athena Mediator
 */

public class LedManager extends Colleague {
    private final LED bleLED;
    private final LED wifiLED;
    private final LED batteryLED;
    private final LED sampleLED;

    public LedManager(Mediator mediator) {
        super(mediator);

        if (mediator.onProductionDevice()) {
            this.bleLED = new HardLED(Constants.LED.BLE);
            this.wifiLED = new HardLED(Constants.LED.WiFi);
            this.batteryLED = new HardLED(Constants.LED.Battery);
            this.sampleLED = new HardLED(Constants.LED.Sampling);
        } else {
            this.bleLED = new SoftLED(Constants.LED.BLE, mediator);
            this.wifiLED = new SoftLED(Constants.LED.WiFi, mediator);
            this.batteryLED = new SoftLED(Constants.LED.Battery, mediator);
            this.sampleLED = new SoftLED(Constants.LED.Sampling, mediator);
        }
    }

    @DebugLog
    public void setLedState(Constants.LED led, boolean on) {
        switch (led) {
            case BLE:
                this.bleLED.setOn(on);
                break;

            case WiFi:
                this.wifiLED.setOn(on);
                break;

            case Sampling:
                this.sampleLED.setOn(on);
                break;

            case Battery:
                this.batteryLED.setOn(on);
                break;
        }
    }
}
