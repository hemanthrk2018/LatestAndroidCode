package com.jci.athena.sensor.sensor;

import android.util.Log;

import com.jci.athena.sensor.Colleague;
import com.jci.athena.sensor.Mediator;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Sensor class. Concrete colleague in the Athena Mediator
 */

public class Sensor extends Colleague {
    private static final CppBridge cppBridge = new CppBridge();

    private CaptureStatus captureStatus;

    public Sensor(Mediator mediator) {
        super(mediator);
        cppBridge.registerHandler(new SensorHandler(mediator));
        cppBridge.setMediator(mediator);
        this.captureStatus = CaptureStatus.NOT_STARTED;
    }

    public void startCapture(String captureId, int durationMilliseconds) {
        Log.i("Sensor", "duration: " + durationMilliseconds);
        cppBridge.start(captureId);
        this.captureStatus = CaptureStatus.STARTED;

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                stopCapture();
            }
        }, durationMilliseconds);
    }

    public void stopCapture() {
        cppBridge.stop();
        this.captureStatus = CaptureStatus.FINISHED_NORMALLY;
    }

    public CaptureStatus captureStatus() {
        return captureStatus;
    }

    public void turnOnAthenaBoard(){
        cppBridge.turnOnAthenaBoard();
    }

    public void turnOffAthenaBoard(){
        cppBridge.turnOffAthenaBoard();
    }
}
