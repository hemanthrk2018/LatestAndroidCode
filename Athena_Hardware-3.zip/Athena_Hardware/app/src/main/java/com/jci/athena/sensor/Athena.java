package com.jci.athena.sensor;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.util.Log;

import com.jci.athena.sensor.ble.BLE;
import com.jci.athena.sensor.led.LedManager;
import com.jci.athena.sensor.sensor.Sensor;
import com.jci.athena.sensor.storage.Storage;
import com.jci.athena.sensor.webclient.WebClient;
import com.jci.athena.wire.Measurements;

import java.io.IOException;
import java.util.List;

import hugo.weaving.DebugLog;

/**
 * Athena Service. Main entry point.
 */

public class Athena extends Service {
    private static final String TAG = "Athena";
    private final IBinder mBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        public Athena getService() {
            return Athena.this;
        }
    }

    private AthenaObject obj;

    @NonNull
    @Override
    @DebugLog
    public IBinder onBind(Intent intent) {
        // Effectively, this is the constructor.
        Context context = this.getApplicationContext();

        this.obj = new AthenaObject(context);
        return mBinder;
    }

//    @Override
//    public int onStartCommand(Intent intent, int flags, int startId) {
//        Context context = this.getApplicationContext();
//        this.obj = new AthenaObject(context);
//
//        return super.onStartCommand(intent,flags,startId);
//    }

    /**
     * <p>AthenaObject is the top-level busines object in the project. It implements the
     * <a href="https://en.wikipedia.org/wiki/Mediator_pattern">Mediator Pattern</a> in general
     * and this project's {@link Mediator} Interface in particular.
     * </p>
     * <p>The Principal Responsibility of this Class is to allow for collaboration between the
     * {@link Colleague}s. Therefore, strive to perform as little non-collaborative work as possible
     * in this class.
     * </p>
      */
    private class AthenaObject implements Mediator {
        private final Context context;

        // Colleagues for the app. Each can do their own thing (a variant of "Single Responsibility
        // Principle"), and when they need to collaborate, this object (the Mediator) needs to
        // expose an API to do so.
        private final BLE ble;
        private final WebClient webClient;
        private final Storage storage;
        private final Sensor sensor;
        private final LedManager ledManager;

        AthenaObject(Context context) {
            this.context = context;

            this.ble = new BLE(this, context);
            this.webClient = new WebClient(this);
            this.storage = new Storage(this);
            this.sensor = new Sensor(this);
            this.ledManager = new LedManager(this);

            this.ble.enable();
        }

        public Context getContext() {
            return context;
        }

        public boolean onProductionDevice() {
            return Build.BRAND.equals("jci");
        }


        // global methods for colleagues:

        // Sensor
        public void startOrStopCapture(String measurementId, int duration) {
            startCapture(measurementId, duration);
        }

        public void buildMeasurementStatus(Measurements.Status.Builder builder) {
            builder.setMeasurementId("");

            switch (this.sensor.captureStatus()) {
                case NOT_STARTED:
                    builder.setStatus(Measurements.StatusEnum.MEASUREMENT_NOT_STARTED);
                    break;

                case STARTED:
                    builder.setStatus(Measurements.StatusEnum.MEASUREMENT_STARTED);
                    break;

                case FINISHED_NORMALLY:
                    builder.setStatus(Measurements.StatusEnum.MEASUREMENT_FINISHED_NORMALLY);
                    break;

                case FINISHED_ABNORMALLY:
                    builder.setStatus(Measurements.StatusEnum.MEASUREMENT_FINISHED_ABNORMALLY);
                    break;
            }
        }

        public void notifySensorFinished() {
            this.ble.notifyStopCapture();
            ledManager.setLedState(Constants.LED.Battery, false);
        }

        // Storage

        public void storeWifiCredentials(String ssid, String presharedKey) {
            this.storage.storeCredentials(ssid, presharedKey);
        }

        public void saveDataStream(String captureId, byte[] data) {
            try {
                this.storage.saveDataStream(captureId, data);
            } catch (IOException e) {
                Log.e(TAG, "IOException opening data file: " + e.getMessage());
            }
        }

        public void deleteFile(String measurementId) {
            Log.e(TAG, "delete file NOT IMPLEMENTED");
        }

        public void setServerIP(String ipv4) {
            this.storage.storeServerIP(ipv4);
        }

        public String getServerIP(){
            return this.webClient.fetchServerIP();
        }

        public void buildFileListing(Measurements.Listing.Builder builder) {
            storage.buildMeasurementFilesMetadata(builder);
        }

        // State

        public void rememberBleConnectionState(boolean connected) {
            this.ledManager.setLedState(Constants.LED.BLE, connected);
        }

        // Web Client

        public void setWifiPower(boolean on) {
            if (on) {
                this.webClient.enable(this.storage.getCredentials());
                this.ledManager.setLedState(Constants.LED.WiFi, true);
            } else {
                this.webClient.disable();
                this.ledManager.setLedState(Constants.LED.WiFi, false);
            }
        }

        public void wifiConnectionDidSucceed(String ipAddress) {
            Log.i("WiFi Message: ", "Wifi got connected successfully");
        }

        public void buildTransferStatus(Measurements.TransferStatus.Builder builder) {
            // TODO.
        }

        public void triggerFileTransfer(List<String> measurementIds) {
            // TODO.
        }

        public void turnOnAthenaBoard(){
            this.sensor.turnOnAthenaBoard();
        }

        public void turnOffAthenaBoard(){
            this.sensor.turnOffAthenaBoard();
        }

        private void startCapture(String measurementId, int milliseconds) {
            this.ledManager.setLedState(Constants.LED.Battery, true);
            this.sensor.startCapture(measurementId, milliseconds);
        }

        private void stopCapture(String measurementId) {
            this.sensor.stopCapture();
        }

        @Override
        protected void finalize() throws Throwable {
            this.ledManager.setLedState(Constants.LED.BLE, false);
            super.finalize();
        }
    }

}
