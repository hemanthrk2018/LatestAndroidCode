package com.jci.athena.sensor;

import android.content.Context;

/**
 * Colleague interface: Part of the Mediator pattern.
 */

public abstract class Colleague {
    protected final Mediator mediator;

    public Colleague(Mediator mediator) {
        this.mediator = mediator;
    }

    protected Context context() {
        return mediator.getContext();
    }
}
