package com.jci.athena.sensor.webclient;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.util.Base64;
import android.util.Log;

import com.jci.athena.sensor.Colleague;
import com.jci.athena.sensor.ErrorLogger;
import com.jci.athena.sensor.Mediator;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import fi.iki.elonen.NanoHTTPD;
import hugo.weaving.DebugLog;

/**
 * WebClient Colleague
 */

public class WebClient extends Colleague {
    private final WifiManager wifiManager;
    private ScanResultReceiver scanResultReceiver;
    public HTTPServer httpServer;
    public String dirPath = "";
    public ErrorLogger errorLogger = new ErrorLogger();
//    private WiFiDirectBroadcastReceiver wiFiDirectBroadcastReceiver;
//    IntentFilter intentFilter;
//    private final WifiP2pManager mManager;
//    private final WifiP2pManager.Channel mChannel;

    public WebClient(Mediator mediator) {
        super(mediator);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String strDate = dateFormat.format(date);
        this.dirPath = mediator.getContext().getFilesDir().getAbsolutePath() + File.separator + "Logs-" + strDate + ".txt";
        this.wifiManager = (WifiManager) this.context().getApplicationContext().getSystemService(Context.WIFI_SERVICE);//
//        this.mManager = (WifiP2pManager) this.context().getApplicationContext().getSystemService(Context.WIFI_P2P_SERVICE);
//        this.mChannel = this.mManager.initialize(this.context().getApplicationContext(), this.context().getApplicationContext().getMainLooper(), null);
    }

    @DebugLog
    public void enable(String[] credentials) {
        this.wifiManager.setWifiEnabled(true);
//        this.wiFiDirectBroadcastReceiver = new WiFiDirectBroadcastReceiver(this.mManager, this.mChannel, this.context());
//        this.context().registerReceiver(this.wiFiDirectBroadcastReceiver, this.intentFilter);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        this.scanResultReceiver = new ScanResultReceiver(this.wifiManager);
        this.context().registerReceiver(
                this.scanResultReceiver,
                intentFilter
        );
        WifiConfiguration config = new WifiConfiguration();
        config.SSID = "\"" + credentials[0] + "\"";
        config.preSharedKey = "\"" + credentials[1] + "\"";
        this.wifiManager.saveConfiguration();
        int networkId = this.wifiManager.addNetwork(config);
        this.wifiManager.enableNetwork(networkId, true);
        this.wifiManager.reconnect();
    }

    public void disable() {
        List<WifiConfiguration> list = wifiManager.getConfiguredNetworks();
        if(list != null){
            for( WifiConfiguration i : list ) {
                this.wifiManager.removeNetwork(i.networkId);
                this.wifiManager.saveConfiguration();
            }
        }
        this.wifiManager.disconnect();
        this.wifiManager.setWifiEnabled(false);
        if(httpServer != null){
            httpServer.stop();
            httpServer = null;
        }
        this.context().unregisterReceiver(this.scanResultReceiver);
    }

    public String fetchServerIP(){
        if(this.wifiManager.getConnectionInfo() != null){
            int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
            return String.format("%d.%d.%d.%d", (ipAddress & 0xff),(ipAddress >> 8 & 0xff),(ipAddress >> 16 & 0xff),(ipAddress >> 24 & 0xff));
        }
        else{
            return "";
        }
    }

    ////

    @DebugLog
    void enableDidSucceed(String ipAddress) {
        mediator.wifiConnectionDidSucceed(ipAddress);
    }

//    class WiFiDirectBroadcastReceiver extends BroadcastReceiver {
//        private final WifiP2pManager mManager;
//        private final WifiP2pManager.Channel mChannel;
//
//        WiFiDirectBroadcastReceiver(WifiP2pManager manager, WifiP2pManager.Channel channel, Context context){
//            this.mManager = manager;
//            this.mChannel = channel;
//        }
//
//        private void initiatePeerDiscovery(){
//            this.mManager.discoverPeers(this.mChannel, new WifiP2pManager.ActionListener() {
//                @Override
//                public void onSuccess() {
//                    Log.i("WifiP2P", "Peers discovered");
//                }
//
//                @Override
//                public void onFailure(int reason) {
//                    Log.e("WifiP2P", "Error while fetching peer discovery");
//                }
//            });
//        }
//
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            String action = intent.getAction();
//            if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
//                int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
//                if(state == WifiP2pManager.WIFI_P2P_STATE_ENABLED){
//                    initiatePeerDiscovery();
//                }
//            } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
//
//            } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
//
//            } else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action)) {
//
//            }
//        }
//    }

    /* This is for the WifiManager code. We need to write the corresponding code for the WifiP2PManager */


//    class NetworkConnector {
//        private static final String TAG = "NetworkConnector";
//        private final String password;
//
//        NetworkConnector(String password) {
//            this.password = password;
//        }
//
//        @DebugLog
//        void connect(ScanResult result) {
//            Configurer configurer = new Configurer(wifiManager, result, password);
//
//            Log.i(TAG, "configurer: " + configurer);
//            ConnectivityManager connectivityManager =
//                    (ConnectivityManager) context().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
//            NetCallback callback = new NetCallback(connectivityManager);
//
//            int networkId = configurer.configuration().networkId;
//            Log.i(TAG, "networkId: " + networkId);
//            wifiManager.disconnect();
//            boolean ok = wifiManager.enableNetwork(networkId, false);
//            Log.i(TAG, "enable network: " + ok);
//
//            NetworkRequest networkRequest =
//                    new NetworkRequest.Builder()
//                            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
//                            .build();
//
//            connectivityManager.registerNetworkCallback(networkRequest, callback);
//
//            Log.i(TAG, "reconnecting...");
//            wifiManager.reconnect();
//        }
//    }

    class ScanResultReceiver extends BroadcastReceiver {
        private final WifiManager wifiManager;

        ScanResultReceiver(WifiManager wifiManager) {
            this.wifiManager = wifiManager;
        }

        @Override
        @DebugLog
        public void onReceive(Context context, Intent intent) {
            Log.i("WifiManager", "On receive method got called");
            String action = intent.getAction();
            if (WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(action)) {
                if(wifiManager.getConnectionInfo() !=  null){
                    int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
                    String ip = String.format("%d.%d.%d.%d", (ipAddress & 0xff),(ipAddress >> 8 & 0xff),(ipAddress >> 16 & 0xff),(ipAddress >> 24 & 0xff));
                    if(!ip.equalsIgnoreCase("0.0.0.0")){
                        Log.i("WifiManager", "The ip address is: " + ip);
                        errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": The IP Address is - " + ip);
                        if(httpServer == null){
                            try{
                                mediator.setServerIP(ip);
                                httpServer = new HTTPServer();
                            }
                            catch (Exception e) {
                                Log.i("HTTPServer", e.getMessage());
                                errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Error in initializing HTTP Server - " + e.getMessage());
                            }
                        }
                    }
                }
            }
            else if(WifiManager.WIFI_STATE_CHANGED_ACTION.equalsIgnoreCase(action)) {
                if(wifiManager.isWifiEnabled()){
                    Log.i("WifiManager", "Wifi got enabled");
                    errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": WiFi is enabled now.");
                }
            }
//            else if(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equalsIgnoreCase(action)){
//                Log.i("WifiManager", "Scan result size: " + wifiManager.getScanResults().size());
//            }
//            ScanResult goodResult = null;
//            Log.i("Wifi", "The scanned devices are: " + this.wifiManager.getScanResults().size());
//            for (ScanResult result : this.wifiManager.getScanResults()) {
//                if (this.ssid.equals(result.SSID)) {
//                    goodResult = result;
//                    break;
//                }
//            }
//            Log.i("Wifi", "Reached in here");
//            context().unregisterReceiver(this);
//            if (goodResult != null) {
//               connector.connect(goodResult);
//            }
        }
    }


//    class NetCallback extends ConnectivityManager.NetworkCallback {
//        private static final String TAG = "NetCallback";
//        private final ConnectivityManager connectivityManager;
//
//        NetCallback(ConnectivityManager connectivityManager) {
//            this.connectivityManager = connectivityManager;
//        }
//
//        @DebugLog
//        @Override
//        public void onAvailable(Network network) {
//            super.onAvailable(network);
//            InetAddress address = detectInternetInterface(getInterfaces());
//            Log.i(TAG, "address: " + address);
//            if (address != null) {
//                //initiateConnection();
//                enableDidSucceed(address.getHostAddress());
//                this.connectivityManager.unregisterNetworkCallback(this);
//            }
//        }
//
//        @DebugLog
//        private InetAddress detectInternetInterface(Enumeration<NetworkInterface> ifaces) {
//            while (ifaces.hasMoreElements()) {
//                NetworkInterface iface = ifaces.nextElement();
//
//                boolean isPossiblyGoodInterface = false;
//                try {
//                    isPossiblyGoodInterface = iface.isUp() && !iface.isLoopback();
//                } catch (SocketException ignored) {}
//
//                if (isPossiblyGoodInterface) {
//                    Enumeration<InetAddress> addresses = iface.getInetAddresses();
//                    InetAddress address;
//                    while(addresses.hasMoreElements()) {
//                        address = addresses.nextElement();
//                        if (isValidIPAddress(address)) {
//                            return address;
//                        }
//                    }
//                }
//            }
//            return null;
//        }
//
//        private Enumeration<NetworkInterface> getInterfaces() {
//            try {
//                return NetworkInterface.getNetworkInterfaces();
//            } catch (SocketException e) {
//                return new Enumeration<NetworkInterface>() {
//                    @Override
//                    public boolean hasMoreElements() {
//                        return false;
//                    }
//
//                    @Override
//                    public NetworkInterface nextElement() {
//                        return null;
//                    }
//                };
//            }
//        }
//
//        private boolean isValidIPAddress(InetAddress address) {
//            return !(
//                    address.isLoopbackAddress() ||
//                            address.isAnyLocalAddress() ||
//                            address.isLinkLocalAddress() ||
//                            address.isMulticastAddress()
//            );
//        }
//
//    }

    public class HTTPServer extends NanoHTTPD {

        private final static int PORT = 8000;
        public HTTPServer() throws IOException {
            super(PORT);
            start();
            Log.i("HttpServer", "Running...");
            errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Running...");
        }

        @Override
        public Response serve(IHTTPSession session){
            Log.e("HTTPServer", "The request was made!!");
            String fileName = session.getQueryParameterString();
            byte[] bytes = null;
            FileInputStream fis = null;
            if(fileName != null) {
                try {
                    String fileId = fileName.split("=")[1];
                    fis = mediator.getContext().openFileInput ( fileId + ".bin");
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    bytes = new byte[(int) fis.getChannel().size()];
                    int count;
                    while((count = fis.read(bytes)) != -1) {
                        bos.write(bytes, 0, count);
                    }
                    bos.flush();
                    bos.close();
                    fis.close();
                }
                catch(Exception e) {
                    Log.e("File Exception: ", e.getMessage());
                    errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Error in converting the file to bytes - " + e.getMessage());
                }
            }
            if("/getMeasurementFile".equalsIgnoreCase(session.getUri())){
//                Base64 codec = new Base64();
//                byte[] base64Bytes = codec.encode(bytes);
//                String base64String = new String(base64Bytes);

                String base64String = "";
                if(bytes != null && bytes.length > 0){
                    try{
                        byte[] byteEncoded = Base64.encode(bytes, Base64.NO_WRAP);
                        base64String = new String(byteEncoded, "UTF-8");
                    }
                    catch(Exception e){
                        base64String =  "";
                        Log.e("HTTPServer", e.getMessage());
                        errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": The error while converting to base64 string - " + e.getMessage());
                    }
                }
                return newFixedLengthResponse(base64String);
                //return newFixedLengthResponse(Response.Status.OK, "application/octet-stream", fis, bytes.length);
            }
            else if ("/getByteLength".equalsIgnoreCase(session.getUri())){
                return newFixedLengthResponse(bytes.length + "");
            }
            return newFixedLengthResponse("Android server welcomes you to the magical land of vibrational analysis...");
        }
    }
}
