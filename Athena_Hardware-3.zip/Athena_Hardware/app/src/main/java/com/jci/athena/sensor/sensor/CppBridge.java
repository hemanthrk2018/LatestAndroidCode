package com.jci.athena.sensor.sensor;

import android.content.Context;
import android.os.Handler;
import android.support.annotation.Keep;
import android.util.Log;

import com.jci.athena.sensor.ErrorLogger;
import com.jci.athena.sensor.Mediator;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * C++ Bridge for the sensor
 */

class CppBridge {
    private CaptureThread captureThread;
    private Thread thread;
    private ISensorHandler handler;
    private Mediator mediator;
    private FileOutputStream fileOutputStream = null;
    public byte[] g_byte = new byte[0];
    private boolean flag = false;
    private String captureId;
    int lastIndex = 0;
    ErrorLogger errorLogger = new ErrorLogger();
    String dirPath = "";
    static {
        System.loadLibrary("athena-interop");
    }

    private native int startCapture();
    private native int stopCapture();
    private native int sensorAvailable();
    private native void turnOn();
    private native void turnOff();

    void registerHandler(ISensorHandler handler_) {
        this.handler = handler_;
    }

    void setMediator(Mediator mediator) {
        this.mediator = mediator;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String strDate = dateFormat.format(date);
        this.dirPath = this.mediator.getContext().getFilesDir().getAbsolutePath() + File.separator + "Logs-" + strDate + ".txt";
    }

    void deviceCommandsForDataCollection(String command, String value){
        try {
            String filename = command;
            FileOutputStream outputStream = new FileOutputStream(filename, false);
            byte[] bytes = value.getBytes();
            outputStream.write(bytes);
            outputStream.close();
        } catch (Exception e) {
            Log.e("Athena Sensor", "Could not write to Sensor: " + e.getMessage());
        }
    }

    void start(String captureId) {
        int availability = this.sensorAvailable();
        this.captureId = captureId;
        this.handler.setCaptureId(captureId);
        this.captureThread = new CaptureThread();
        ThreadGroup group = new ThreadGroup("threadGroup");
        thread = new Thread(group, this.captureThread, this.captureId, 20000000);
        //thread = new Thread(this.captureThread);
        thread.start();
//        try{
//            deviceCommandsForDataCollection("/sys/devices/system/cpu/cpu0/core_ctl/min_cpus", "4");
//           thread.sleep(10);
//            deviceCommandsForDataCollection("/sys/class/jci_ad7768/pwr_1p8v/value", "1");
//           thread.sleep(10);
//            deviceCommandsForDataCollection("/sys/class/jci_ad7768/pwr_5v/value", "1");
//           thread.sleep(10);
//            deviceCommandsForDataCollection("/sys/class/jci_ad7768/reset/value", "1");
//           thread.sleep(10);
//        }
//        catch(Exception e){
//            this.errorLogger.appendLog(dirPath, System.currentTimeMillis() + ": " + e.getMessage());
//        }
        try {
            this.fileOutputStream = this.mediator.getContext().openFileOutput(this.captureId + ".bin", Context.MODE_PRIVATE);
        }
        catch (Exception e){
            this.errorLogger.appendLog(this.dirPath, System.currentTimeMillis() + ": " + e.getMessage());
        }
    }

    void stop(){
        Log.i("CppBridge", "Stopping thread");
        this.errorLogger.appendLog(this.dirPath, "\n" + System.currentTimeMillis() + ": Stopping thread");
        stopCapture();
    }

    void turnOnAthenaBoard(){
        this.turnOn();
    }

    void turnOffAthenaBoard(){
        this.turnOff();
    }

    @Keep
    private void callback(byte[] data) {
        if (this.handler != null) {
            this.handler.handleData(data);
            try {
                //this.fileOutputStream.write(data);
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                outputStream.write(this.g_byte);
                outputStream.write(data);
                this.g_byte = outputStream.toByteArray();
                //getByteChunks(this.g_byte);
            }
            catch(Exception e){
                Log.e("File Exception: ", e.getMessage());
                errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Error in callback function " + e.getMessage());
            }
        }
    }

    public void getByteChunks(byte[] byteArray){
        if(this.lastIndex < byteArray.length){
            byte[] channelData = null;
            for(int i = 0; i < 12; i++){
                channelData[i] = byteArray[this.lastIndex + i];
            }
            doCRCValidation(channelData);
        }
    }

    public void doCRCValidation(byte[] byteArray){
        byte[] channel0 = null;
        byte[] channel1 = null;
        byte[] channel2 = null;
        for(int i = 0; i < byteArray.length; i++){
            if(i < 4){
                channel0[i] = byteArray[i];
            }
            else if(i >= 4 && i < 8){
                channel1[i-4] = byteArray[i];
            }
            else{
                channel1[i-8] = byteArray[i];
            }
        }
        initiateCRCCheck(channel0);
        initiateCRCCheck(channel1);
        initiateCRCCheck(channel2);
        this.lastIndex += 12;
        getByteChunks(g_byte);
    }

    public void initiateCRCCheck(byte[] byteArray){
        int intRepresentation = ByteBuffer.wrap(byteArray).getInt();
        int i = 0x800000;
        char crc = 0xff;
        while(i != 0){
            if(((crc & 0x80) != 0) != ((intRepresentation & i) != 0)){
                crc <<= 1;
                crc ^= 0x07;
            }
            else{
                crc <<= 1;
            }
        }
        if(crc == 4){
            Log.e("CRC: ", "CRC Failed");
        }
    }

    private class CaptureThread implements Runnable {
        CaptureThread() {}

        @Override
        public void run() {
            //Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            int ret = startCapture();
            try {
                Log.i("Data Collection", "Final Byte length: " + Integer.toString(g_byte.length));
                errorLogger.appendLog(dirPath,"\n" + System.currentTimeMillis() + ": Final Byte length " + Integer.toString(g_byte.length));
                fileOutputStream.write(g_byte);
                g_byte = new byte[0];
                notifyDone();
            }
            catch (Exception e){
                errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Error while data collection " + e.getMessage());
            }
        }

        private void notifyDone() {
            // Get a handler that can be used to post to the main thread
            if(mediator != null) {
                Handler mainHandler = new Handler(mediator.getContext().getMainLooper());
                Runnable myRunnable = new Runnable() {
                    @Override
                    public void run() {
                        errorLogger.appendLog(dirPath,"\n" + System.currentTimeMillis() + ": Notify got called successfullly");
                        mediator.notifySensorFinished();
                    }
                };
                mainHandler.post(myRunnable);
            }
        }
    }

}
