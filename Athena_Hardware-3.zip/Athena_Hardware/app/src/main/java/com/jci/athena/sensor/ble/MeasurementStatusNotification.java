package com.jci.athena.sensor.ble;

import com.jci.athena.wire.Measurements;

/**
 * Protobuf encoder for Measurement Status
 */

public class MeasurementStatusNotification {
}
