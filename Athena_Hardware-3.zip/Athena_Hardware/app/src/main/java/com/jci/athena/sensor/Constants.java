package com.jci.athena.sensor;

import java.util.UUID;

/**
 * BLE Constants
 */

public interface Constants {
    UUID SERVICE_UUID =
            UUID.fromString("DE1769A1-57AC-423F-9E82-970D25656151");

    // Characteristic UUIDs:

    // Measurement UUIDs:
    // write
    UUID MEASUREMENT_TRIGGER_UUID =
            UUID.fromString("3BF60EE1-B5F7-4B45-B3F1-8DF7DFD3510B");

    // read, notify
    UUID MEASUREMENT_STATUS_UUID =
            UUID.fromString("14493D33-9F58-4850-81C7-5F6E3CA7A8A3");
    UUID MEASUREMENT_STATUS_NOTIFICATION_DESCRIPTOR_UUID =
            UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");

    // read
    UUID FETCH_MEASUREMENT_FILE_LISTING_UUID =
            UUID.fromString("82EDB2F0-1714-423F-B37C-39319001E0FE");

    // write
    UUID REQUEST_WIFI_POWER_UUID =
            UUID.fromString("55B02062-31F4-4F79-98E3-3ECD5EE67DD4");

    // write
    UUID TRANSFER_MEASUREMENT_FILES_UUID =
            UUID.fromString("8339106B-9EDF-4613-BC14-4D9050E4B9C5");
    // read (maybe notify)
    UUID TRANSFER_STATUS_UUID =
            UUID.fromString("F8CFD657-6FB3-4A87-ACE9-7D2A3DB60BEF");

    // write
    UUID DELETE_MEASUREMENT_FILE_UUID =
            UUID.fromString("1E7E9A1B-9EBE-4397-B9B5-FFEFF75AEEA1");


    // WiFi Characeteristics:
    // write
    UUID WIFI_CREDS_UUID =
            UUID.fromString("16226AF7-ABD7-4EE4-BDDF-ED01122D0C02");
    // read
    UUID WIFI_SERVER_IP_UUID =
            UUID.fromString("65169FC4-9956-482E-A6AC-BECB2BBEF7A1");


    // These are "virtual" LEDs. Technically, there is no BLE LED, but we want to
    // act as if there is. The underlying LED architecture will decide which physical LED
    // to light up.
    enum LED {
        BLE,
        WiFi,
        Sampling,
        Battery
    }
}
