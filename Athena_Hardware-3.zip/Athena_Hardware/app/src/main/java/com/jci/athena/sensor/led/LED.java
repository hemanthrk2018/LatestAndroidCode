package com.jci.athena.sensor.led;

import com.jci.athena.sensor.Constants;

/**
 * Interface for generic LED. Can be a real LED or a fake one on a screen.
 */

abstract class LED {
    protected final Constants.LED led;
    LED(Constants.LED led) {
        this.led = led;
    }

    abstract void setOn(boolean on);

    public String getName() {
        switch (this.led) {
            case BLE:
                return "BLE";
            case WiFi:
                return "WiFi";
            case Sampling:
                return "Sampling";
            case Battery:
                return "Battery";
            default:
                return "<unknown>";
        }
    }
}
