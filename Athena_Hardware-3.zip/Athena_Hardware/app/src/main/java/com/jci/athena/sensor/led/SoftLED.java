package com.jci.athena.sensor.led;

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;

import com.jci.athena.sensor.Constants;
import com.jci.athena.sensor.Mediator;

/**
 * Software LED. For development purposes
 */

class SoftLED extends LED {
    private final Mediator mediator;

    SoftLED(Constants.LED led, Mediator mediator) {
        super(led);
        this.mediator = mediator;
    }

    public void setOn(boolean on) {
        Intent broadcastIntent = new Intent("ledChange");

        int ledId = -1;
        switch (this.led) {
            case BLE:
                ledId = 0; break;
            case WiFi:
                ledId = 1; break;
            case Sampling:
                ledId = 2; break;
        }

        broadcastIntent.putExtra("led", ledId);
        LocalBroadcastManager broadcaster = LocalBroadcastManager.getInstance(this.mediator.getContext());
        broadcaster.sendBroadcast(broadcastIntent);
    }
}