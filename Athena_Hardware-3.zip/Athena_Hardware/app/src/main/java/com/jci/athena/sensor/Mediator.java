package com.jci.athena.sensor;

import android.content.Context;

import com.jci.athena.wire.Measurements;

import java.util.List;

/**
 * Mediator. Part of the Mediator pattern.
 */

public interface Mediator {
    // Methods to forward from one colleague to another go here:

    Context getContext();
    boolean onProductionDevice();

    // Sensor
    void startOrStopCapture(String measurementId, int milliseconds);
    void buildMeasurementStatus(Measurements.Status.Builder buidler);
    void notifySensorFinished();
    void turnOnAthenaBoard();
    void turnOffAthenaBoard();

    // Storage
    void storeWifiCredentials(String ssid, String presharedKey);
    void saveDataStream(String captureId, byte[] data);
    void deleteFile(String measurementId);
    void setServerIP(String ipv4);
    String getServerIP();
    void buildFileListing(Measurements.Listing.Builder builder);

    // State
    void rememberBleConnectionState(boolean connected);

    // Web Client
    void wifiConnectionDidSucceed(String ipAddress);
    void setWifiPower(boolean on);
    void buildTransferStatus(Measurements.TransferStatus.Builder builder);
    void triggerFileTransfer(List<String> measurementIds);
}
