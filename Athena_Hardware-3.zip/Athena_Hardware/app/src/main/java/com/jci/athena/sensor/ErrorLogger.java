package com.jci.athena.sensor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by jrathig on 4/3/2018.
 */

public class ErrorLogger {

    private Mediator mediator;

    public void appendLog(String dirPath, String text)
    {
        File logFile = new File(dirPath);
        if (!logFile.exists())
        {
            try
            {
                logFile.createNewFile();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        try
        {
            //BufferedWriter for performance, true to set append to file flag
            BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true));
            buf.append(System.lineSeparator());
            buf.append(text);
            buf.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
