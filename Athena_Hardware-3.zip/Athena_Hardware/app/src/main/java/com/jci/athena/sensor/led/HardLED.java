package com.jci.athena.sensor.led;

import android.support.annotation.NonNull;
import android.util.Log;

import com.jci.athena.sensor.Constants;

import org.jetbrains.annotations.Contract;

import java.io.FileOutputStream;

/**
 * Hardware LED
 */

class HardLED extends LED {
    HardLED(Constants.LED led) {
        super(led);
    }

    public void setOn(boolean on) {
        try {
            String filename = "/sys/class/jci_led/" + pathToken() + "/value";
            FileOutputStream outputStream = new FileOutputStream(filename, false);
            byte[] bytes = (on ? "1" : "0").getBytes();
            outputStream.write(bytes);
            outputStream.close();
        } catch (Exception e) {
            Log.e("Athena hLED", "Could not write to LED: " + e.getMessage());
            Log.e("Athena hLED", "Perhaps you need to do `setenforce 0`?");
        }
    }

    @Contract(pure = true)
    @NonNull
    private String pathToken() {
        switch (this.led) {
            case BLE: return "led_samp_b";
            case WiFi: return "led_wifi";
            case Sampling: return "led_samp_g";
            case Battery: return "led_batt_0";
        }
        return null;
    }
}