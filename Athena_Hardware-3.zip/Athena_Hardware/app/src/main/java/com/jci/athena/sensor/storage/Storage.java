package com.jci.athena.sensor.storage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.util.Log;

import com.jci.athena.sensor.Colleague;
import com.jci.athena.sensor.Mediator;
import com.jci.athena.wire.Measurements;

import java.io.FileOutputStream;
import java.io.IOException;


/**
 * Storage class. Concrete colleague in the Athena Mediator
 */

public class Storage extends Colleague {
    private static final String TAG = "Storage";

    private final StorageDbHelper dbHelper;
    private SQLiteDatabase db;
    private FileOutputStream fileOutputStream = null;

    private static final String SQL_CREATE_WIFI_CREDENTIALS =
            "CREATE TABLE " + StorageContract.WiFiCredentials.TABLE_NAME + " (" +
                    StorageContract.WiFiCredentials._ID + " INTEGER PRIMARY KEY, " +
                    StorageContract.WiFiCredentials.COLUMN_NAME_SSID + " TEXT, " +
                    StorageContract.WiFiCredentials.COLUMN_NAME_PASSWORD + " TEXT)";

    private static final String SQL_CREATE_SERVER_IP =
            "CREATE TABLE " + StorageContract.ServerIP.TABLE_NAME + " (" +
                    StorageContract.ServerIP._ID + " INTEGER PRIMARY KEY, " +
                    StorageContract.ServerIP.COLUMN_NAME_SERVER_IP + " TEXT) ";

    private static final String SQL_DELETE_WIFI_CREDENTIALS =
            "DROP TABLE IF EXISTS " + StorageContract.WiFiCredentials.TABLE_NAME;

    private static final String SQL_DELETE_SERVER_IP =
            "DROP TABLE IF EXISTS " + StorageContract.ServerIP.TABLE_NAME;

    public Storage(Mediator mediator) {
        super(mediator);
        this.dbHelper = new StorageDbHelper(mediator.getContext());
        bootSqlite();
    }

    private void bootSqlite() {
        new AsyncTask<StorageDbHelper, String, SQLiteDatabase>() {
            @Override
            protected SQLiteDatabase doInBackground(StorageDbHelper... params) {
                return params[0].getWritableDatabase();
            }

            @Override
            protected void onPostExecute(SQLiteDatabase sqLiteDatabase) {
                super.onPostExecute(sqLiteDatabase);
                setDb(sqLiteDatabase);
            }
        }.execute(dbHelper);
    }

    private void setDb(SQLiteDatabase newDb) {
        this.db = newDb;
    }


    public void storeCredentials(String ssid, String presharedKey) {
        Log.i(TAG, "Storing " + ssid + " and " + presharedKey);
        ContentValues values = new ContentValues();
        values.put(StorageContract.WiFiCredentials.COLUMN_NAME_SSID, ssid);
        values.put(StorageContract.WiFiCredentials.COLUMN_NAME_PASSWORD, presharedKey);
        int count = db.update(
                StorageContract.WiFiCredentials.TABLE_NAME,
                values,
                null,
                null
        );

        Log.i(TAG, "Updated " + count + " row(s) for wifi credentials");
    }

    public void storeServerIP(String ipAddress) {
        Log.i(TAG, "Storing " + ipAddress);
        ContentValues values = new ContentValues();
        values.put(StorageContract.ServerIP.COLUMN_NAME_SERVER_IP, ipAddress);
        int count = db.update(
                StorageContract.ServerIP.TABLE_NAME,
                values,
                null,
                null
        );

        Log.i(TAG, "Updated " + count + " row(s) for server ip");
    }

    public String[] getCredentials() {
        String[] projection = {
                StorageContract.WiFiCredentials.COLUMN_NAME_SSID,
                StorageContract.WiFiCredentials.COLUMN_NAME_PASSWORD
        };
        Cursor cursor = db.query(
                StorageContract.WiFiCredentials.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );
        cursor.moveToNext();
        String ssid = cursor.getString(cursor.getColumnIndexOrThrow(StorageContract.WiFiCredentials.COLUMN_NAME_SSID));
        String password = cursor.getString(cursor.getColumnIndexOrThrow(StorageContract.WiFiCredentials.COLUMN_NAME_PASSWORD));
        cursor.close();

        return new String[]{ssid, password};
    }

    public String getServerIP() {
        String[] projection = {
                StorageContract.ServerIP.COLUMN_NAME_SERVER_IP,
        };

        Cursor cursor = db.query(
                StorageContract.ServerIP.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );
        cursor.moveToNext();
        String ipAddress = cursor.getString(cursor.getColumnIndexOrThrow(StorageContract.ServerIP.COLUMN_NAME_SERVER_IP));
        cursor.close();
        return ipAddress;
    }

    public void saveDataStream(String captureId, byte[] data) throws IOException {
        this.openDataFileIfNecessary(captureId);
        this.appendDataFile(data);
    }

    public void buildMeasurementFilesMetadata(Measurements.Listing.Builder builder) {
        // TODO: This is just a sample implementation
        Measurements.File.Builder fileBuilder = Measurements.File.newBuilder();
        for (int i = 0; i < 4; i++) {
            fileBuilder.clear();
            fileBuilder.setFilesize(i * 1000);
            fileBuilder.setMeasurementId("file_" + i + ".mea");
            fileBuilder.setStartedAtMilliTimestamp1970(i);

            builder.addMeasurementFiles(fileBuilder.build());
        }
    }

    private void openDataFileIfNecessary(String captureId) throws IOException {
        if (this.fileOutputStream == null) {
            this.fileOutputStream = this.mediator.getContext().openFileOutput(captureId, Context.MODE_PRIVATE);
            Log.i(TAG, "Writing to: " + this.fileOutputStream.toString());
        }
    }

    private void appendDataFile(byte[] data) throws IOException {
        this.fileOutputStream.write(data);
    }

    public void closeDataFile() throws IOException {
        this.fileOutputStream.close();
        this.fileOutputStream = null;
    }

    private class StorageDbHelper extends SQLiteOpenHelper {
        static final int DATABASE_VERSION = 9;
        static final String DATABASE_NAME = "Athena.db";

        StorageDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_WIFI_CREDENTIALS);

            ContentValues values = new ContentValues();
            values.put(StorageContract.WiFiCredentials.COLUMN_NAME_SSID, "");
            values.put(StorageContract.WiFiCredentials.COLUMN_NAME_PASSWORD, "");
            db.insert(StorageContract.WiFiCredentials.TABLE_NAME, null, values);

            db.execSQL(SQL_CREATE_SERVER_IP);
            values = new ContentValues();
            values.put(StorageContract.ServerIP.COLUMN_NAME_SERVER_IP, "");
            db.insert(StorageContract.ServerIP.TABLE_NAME, null, values);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // Just delete and reinitialize for now
            db.execSQL(SQL_DELETE_WIFI_CREDENTIALS);
            db.execSQL(SQL_DELETE_SERVER_IP);
            onCreate(db);
        }

        public void deleteServerIPTable(){
            db.execSQL(SQL_DELETE_SERVER_IP);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }
}
