package com.jci.athena.sensor.webclient;

import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.support.annotation.NonNull;

import hugo.weaving.DebugLog;

/**
 * Configures networks that aren't yet configured. Simply passes through already-configured networks.
 */

public class Configurer {
    private final WifiManager manager;
    private final ScanResult scanResult;
    private final WifiConfiguration configuration;

    @DebugLog
    public Configurer(WifiManager manager, ScanResult result, String password) {
        this.manager = manager;
        this.scanResult = result;
        this.configuration = determineConfiguration(password);
    }

    @NonNull
    @DebugLog
    WifiConfiguration configuration() {
        return this.configuration;
    }

    @NonNull
    private WifiConfiguration determineConfiguration(String password) {
        for (WifiConfiguration config :
                this.manager.getConfiguredNetworks()) {
            if (config.BSSID != null && config.BSSID.equals(this.scanResult.BSSID)) {
                config.preSharedKey = "\"" + password + "\"";
                this.manager.updateNetwork(config);
                return config;
            }
        }

        WifiConfiguration newConfig = scanResultToConfiguration(password);
        this.manager.addNetwork(newConfig);
        return newConfig;
    }

    @NonNull
    private WifiConfiguration scanResultToConfiguration(String password) {
        WifiConfiguration wc = new WifiConfiguration();
        wc.SSID = this.scanResult.SSID;
        wc.BSSID = this.scanResult.BSSID;
        wc.preSharedKey = "\"" + password + "\"";

        wc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
        wc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);

        wc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);

        wc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
        wc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);

        wc.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
        wc.allowedProtocols.set(WifiConfiguration.Protocol.WPA);

        wc.priority = 999999;

        return wc;

    }
}
