package com.jci.athena.sensor.storage;

import android.provider.BaseColumns;

/**
 * Storage Contract (a.k.a. DB Schema)
 */

final class StorageContract {
    // prevent from accidentally instantiating the contract class:
    private StorageContract() {
    }

    static class WiFiCredentials implements BaseColumns {
        // technically, we only ever want one row in here.
        static final String TABLE_NAME = "wifi_connections";
        static final String COLUMN_NAME_SSID = "ssid";
        static final String COLUMN_NAME_PASSWORD = "password";
    }

    static class ServerIP implements BaseColumns {
        static final String TABLE_NAME = "server_ip_table";
        static final String COLUMN_NAME_SERVER_IP = "server_ip";
    }
}
