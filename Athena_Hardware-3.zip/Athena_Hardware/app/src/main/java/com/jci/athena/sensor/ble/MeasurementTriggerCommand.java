package com.jci.athena.sensor.ble;

import com.jci.athena.wire.Measurements;

/**
 * Measurement Trigger Command
 */

public class MeasurementTriggerCommand {
    public static Measurements.Trigger run(byte[] data) {
        try {
            return Measurements.Trigger.parseFrom(data);
        } catch (com.google.protobuf.InvalidProtocolBufferException e) {
            return null;
        }
    }

}
