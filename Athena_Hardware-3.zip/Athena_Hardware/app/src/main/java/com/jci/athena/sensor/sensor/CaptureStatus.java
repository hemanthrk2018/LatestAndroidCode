package com.jci.athena.sensor.sensor;

/**
 * Enumeration of possible capture statuses
 */

public enum CaptureStatus {
    NOT_STARTED,
    STARTED,
    FINISHED_NORMALLY,
    FINISHED_ABNORMALLY
}
