package com.jci.athena.sensor;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.TextView;


import hugo.weaving.DebugLog;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;


/**
 * MainActivity is the entry activity for the app. Even though the Athena device does not have
 * a screen, Android typically cannot start up a Service without an Activity to control it.
 *
 * In development (on an Android phone), MainActivity can act as a debugging display, showing some
 * {@link FakeLED}s onscreen.
 */

public class MainActivity extends Activity {
    private static final String TAG = "Athena MainActivity";

    private static final int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 0xdead;

    private Athena mBoundCoordinatorService;
    private boolean mCoordinatorIsBound = false;

    private ServiceConnection mCoordinatorConnection = new ServiceConnection() {
        @Override
        @DebugLog
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBoundCoordinatorService = ((Athena.LocalBinder)service).getService();
        }

        @Override
        @DebugLog
        public void onServiceDisconnected(ComponentName name) {
            mBoundCoordinatorService = null;
        }
    };

    @Override
    @DebugLog
    protected void onDestroy() {
        unbindFromCoordinatorService();

        super.onDestroy();
    }


    @Override
    @DebugLog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createUI();
        bindToCoordinatorService();
    }

    private void createUI() {
        setContentView(R.layout.main_activity);
        ((FakeLED)findViewById(R.id.led_1)).setColor("green");
        ((FakeLED)findViewById(R.id.led_2)).setColor("yellow");
        ((FakeLED)findViewById(R.id.led_3)).setColor("red");
    }


    @DebugLog
    private void bindToCoordinatorService() {
        boolean ret = getApplicationContext()
                .bindService(
                    new Intent(this, Athena.class),
                    mCoordinatorConnection,
                    Context.BIND_AUTO_CREATE
                );
        mCoordinatorIsBound = ret;

        listenForLedChangeRequests();
        listenForConnectionStatusChanges();
        listenForCollectingDataStatusChanges();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS) {
            Log.d(TAG, "Coarse location permission results: ");
            for (int i = 0; i < permissions.length; i++ ) {
                Log.d(TAG, permissions[i] + ": " + (grantResults[i] == PERMISSION_GRANTED ? "granted" : "denied"));
            }
        }
    }

    private void listenForLedChangeRequests() {
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            @DebugLog
            public void onReceive(Context context, Intent intent) {
                int led_num = intent.getIntExtra("led", 0);
                int id = getResources().getIdentifier("led_" + led_num, "id", getPackageName());
                FakeLED led = (FakeLED) findViewById(id);
                led.toggle();
            }
        }, new IntentFilter("ledChange"));
    }

    private void listenForConnectionStatusChanges() {
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int newStatus= intent.getIntExtra("newStatus", -1);
                TextView statusView = (TextView) findViewById(R.id.connectionStatusValue);
                if (newStatus == 0) {
                    statusView.setText(R.string.is_connected_value_no);
                } else if (newStatus == 2) {
                    statusView.setText(R.string.is_connected_value_yes);
                } else {
                    statusView.setText(R.string.is_connected_value_error);
                }
            }
        }, new IntentFilter("connectionStatusChange"));
    }

    private void listenForCollectingDataStatusChanges() {
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.i(TAG, "got broadcast: " + intent.getDataString());
                boolean isCollectingData = intent.getBooleanExtra("isCollectingData", false);
                TextView statusView = (TextView) findViewById(R.id.collectingDataValue);
                if (isCollectingData) {
                    statusView.setText(R.string.is_collecting_data_value_yes);
                } else {
                    statusView.setText(R.string.is_collecting_data_value_no);
                }
            }
        }, new IntentFilter(this.getString(R.string.commands__start_measurement__intent)));
    }

    private void unbindFromCoordinatorService() {
        if (mCoordinatorIsBound) {
            getApplicationContext().
                    unbindService(mCoordinatorConnection);
            mCoordinatorIsBound = false;
        }
    }
}
