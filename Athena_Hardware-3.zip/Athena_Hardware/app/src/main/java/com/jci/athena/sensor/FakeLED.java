package com.jci.athena.sensor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Pretends to be an LED
 */

class FakeLED extends View {
    private Paint paint;
    private Paint outlinePaint;
    private boolean isOn = false;


    public FakeLED(Context context) {
        super(context);
        doInit();
    }

    public FakeLED(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        doInit();
    }

    public FakeLED(Context context, AttributeSet attributeSet, int defStyle) {
        super(context, attributeSet, defStyle);
        doInit();
    }

    private void doInit() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setAntiAlias(true);

        outlinePaint = new Paint();
        outlinePaint.setStyle(Paint.Style.STROKE);
        outlinePaint.setStrokeWidth(4);
        outlinePaint.setColor(Color.GRAY);
        outlinePaint.setAntiAlias(true);

    }

    public void setColor(String color) {
        if (color.equals("red"))
            paint.setColor(Color.RED);
        else if (color.equals("yellow"))
            paint.setColor(Color.YELLOW);
        else if (color.equals("green"))
            paint.setColor(Color.GREEN);
    }

    void toggle() {
        isOn = !isOn;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.TRANSPARENT);
        canvas.drawArc(5, 5, 45, 45, 0, 360, false, outlinePaint);
        if (isOn) {
            canvas.drawCircle(25, 25, 14, paint);
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(50, 50 );
    }
}
