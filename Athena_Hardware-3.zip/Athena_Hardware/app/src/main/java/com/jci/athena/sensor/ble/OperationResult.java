package com.jci.athena.sensor.ble;

/**
 * Result of a BLE operation
 */

class OperationResult {
    static final OperationResult emptySuccess = new OperationResult();
    static final OperationResult emptyFailure = new OperationResult(false, new byte[] {});

    private boolean succeeded = true;
    private byte[] response = new byte[] {};

    OperationResult() {}
    OperationResult(boolean succeeded, byte[] response) {
        this.succeeded = succeeded;
        this.response = response;
    }
    boolean isSuccess() { return this.succeeded; }
    byte[] getResponse() { return this.response; }

}
