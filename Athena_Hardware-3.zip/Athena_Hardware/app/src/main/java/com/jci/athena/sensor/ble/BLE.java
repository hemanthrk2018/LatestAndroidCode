package com.jci.athena.sensor.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.os.SystemProperties;
import android.util.Log;

import com.google.protobuf.InvalidProtocolBufferException;
import com.jci.athena.sensor.Colleague;
import com.jci.athena.sensor.Constants;
import com.jci.athena.sensor.ErrorLogger;
import com.jci.athena.sensor.Mediator;
import com.jci.athena.sensor.R;
import com.jci.athena.wire.Measurements;
import com.jci.athena.wire.Wifi;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import hugo.weaving.DebugLog;

import static android.bluetooth.BluetoothGatt.GATT_FAILURE;
import static android.bluetooth.BluetoothGatt.GATT_SUCCESS;
import static android.bluetooth.BluetoothGattCharacteristic.PERMISSION_READ;
import static android.bluetooth.BluetoothGattCharacteristic.PERMISSION_WRITE;
import static android.bluetooth.BluetoothGattCharacteristic.PROPERTY_NOTIFY;
import static android.bluetooth.BluetoothGattCharacteristic.PROPERTY_READ;
import static android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE;
import static android.bluetooth.BluetoothProfile.STATE_CONNECTED;
import static android.bluetooth.le.AdvertiseSettings.ADVERTISE_MODE_BALANCED;


/**
 * BLE class. Concrete colleague in the Athena Mediator
 */

public class BLE extends Colleague {
    // Warning: the bleAdvertisedName must not be longer than 6 characters, lest the advertisement
    // payload be too large for BluetoothLE standards.
    private static String bleAdvertisedName = "VAH ";

    private final Context context;
    private final BluetoothManager bluetoothManager;
    private BluetoothGattServer gattServer;
    private final BluetoothGattServerCallback gattCallback;
    private BluetoothLeAdvertiser advertiser;
    private final AdvertiseCallback advertiseCallback;
    private BluetoothDevice remoteDevice;
    public ErrorLogger errorLogger = new ErrorLogger();
    public String dirPath = "";

    private BluetoothGattCharacteristic measurementStatusCharacteristic;
    private BluetoothGattCharacteristic measurementTriggerCharacteristic;

    public BLE(Mediator mediator, Context context) {
        super(mediator);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String strDate = dateFormat.format(date);
        this.dirPath = this.mediator.getContext().getFilesDir().getAbsolutePath() + File.separator + "Logs-" + strDate + ".txt";
        this.context = context;
        this.bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        this.gattCallback = new GattCallback();
        this.advertiseCallback = new AdCallback();
    }

    public void enable() {
        BluetoothAdapter adapter = bluetoothManager.getAdapter();
        String serialNumber = SystemProperties.get("ro.serialno") + " ";
        String appVersion = context.getString(R.string.appVersion);
        //bleAdvertisedName += serialNumber;
        if (! adapter.setName(bleAdvertisedName) ) {
            Log.e("BLE", "Could not set BluetoothLE Advertising Name");
            errorLogger.appendLog(this.dirPath,"\n" + System.currentTimeMillis() + "Could not set BluetoothLE Advertising Name");
        }
        if (! adapter.enable() ) {
            throw new RuntimeException("Could not enable BluetoothLE");
        }
        this.gattServer = bluetoothManager.openGattServer(this.context, this.gattCallback);
        assert this.gattServer != null;

        this.advertiser = adapter.getBluetoothLeAdvertiser();
        assert this.advertiser != null;

        this.gattServer.addService(this.makeGattService());
        if(adapter.isEnabled()){
            adapter.setName(bleAdvertisedName + serialNumber + appVersion);
        }
        this.advertiser.startAdvertising(adSettings(), adData(), advertiseCallback);
    }

    public void notifyStopCapture() {
        byte[] value = this.measurementStatusCharacteristic.getValue();
        if(value == null) {
            this.measurementStatusCharacteristic.setValue("1");
        }
        this.gattServer.notifyCharacteristicChanged(this.remoteDevice, this.measurementStatusCharacteristic, false);
    }

    private AdvertiseData adData() {
        AdvertiseData.Builder builder = new AdvertiseData.Builder();
        //builder.addServiceUuid(new ParcelUuid(Constants.SERVICE_UUID));
        builder.setIncludeDeviceName(true);
        return builder.build();
    }

    private AdvertiseSettings adSettings() {
        AdvertiseSettings.Builder builder = new AdvertiseSettings.Builder();
        builder.setConnectable(true);
        builder.setAdvertiseMode(ADVERTISE_MODE_BALANCED);
        return builder.build();
    }

    @SuppressWarnings("unused")
    public void disable() {
        this.gattServer.close();
        this.advertiser.stopAdvertising(this.advertiseCallback);
        this.gattServer = null;
    }

    interface IBleParser {
        void perform() throws InvalidProtocolBufferException;
    }

    private class GattCallback extends BluetoothGattServerCallback {
        private static final String TAG = "Athena BLE Callback";

        private OperationResult wrapWrite(String name, IBleParser parser) {
            try {
                Log.e("BLE", "char write request: " + name);
                errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Char Write Request " + name);
                parser.perform();
                return OperationResult.emptySuccess;
            } catch (InvalidProtocolBufferException e) {
                Log.e(TAG, name + " parsing failed: " + e.getMessage());
                errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Parsing Failed " + e.getMessage());
                return OperationResult.emptyFailure;
            }
        }

        private OperationResult getServerIP() {
            String ip = mediator.getServerIP();
            return new OperationResult(true, ip.getBytes());
        }

        private OperationResult getMeasurementStatus() {
            Measurements.Status.Builder builder = Measurements.Status.newBuilder();
            mediator.buildMeasurementStatus(builder);
            return new OperationResult(true, builder.build().toByteArray());
        }

        private OperationResult getFileListing() {
            Measurements.Listing.Builder builder = Measurements.Listing.newBuilder();
            mediator.buildFileListing(builder);
            return new OperationResult(true, builder.build().toByteArray());
        }

        private OperationResult getTransferStatus() {
            Measurements.TransferStatus.Builder builder = Measurements.TransferStatus.newBuilder();
            mediator.buildTransferStatus(builder);
            return new OperationResult(true, builder.build().toByteArray());
        }

        @Override
        @DebugLog
        public void onConnectionStateChange(BluetoothDevice device, int status, int newState) {
            boolean connected = newState == STATE_CONNECTED;
            if(!connected){
                mediator.setWifiPower(false);
                mediator.turnOffAthenaBoard();
            }
            else{
                mediator.turnOnAthenaBoard();
            }
            mediator.rememberBleConnectionState(connected);
            remoteDevice = connected ? device : null;
        }

        @Override
        @DebugLog
        public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId, BluetoothGattCharacteristic characteristic, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
            UUID uuid = characteristic.getUuid();
            OperationResult result;

            if (uuid.equals(Constants.MEASUREMENT_TRIGGER_UUID)) {
                result = wrapWrite("measure request", () -> {
                    Measurements.Trigger trigger = Measurements.Trigger.parseFrom(value);
                    mediator.startOrStopCapture(trigger.getMeasurementId(), trigger.getDurationInMilliseconds());
                });
            } else if (uuid.equals(Constants.REQUEST_WIFI_POWER_UUID)) {
                result = wrapWrite("toggle wifi", () -> {
                    mediator.setWifiPower(Wifi.SetPower.parseFrom(value).getTurnOn());
                });
            } else if (uuid.equals(Constants.DELETE_MEASUREMENT_FILE_UUID)) {
                result = wrapWrite("delete file", () -> {
                    mediator.deleteFile(Measurements.Delete.parseFrom(value).getMeasurementId());
                });
            } else if (uuid.equals(Constants.WIFI_CREDS_UUID)) {
                result = wrapWrite("wifi creds", () -> {
                    Log.e(TAG, "payload was: " + this.bytesToString(value));
                    Wifi.Credentials creds = Wifi.Credentials.parseFrom(value);
                    mediator.storeWifiCredentials(creds.getSsid(), creds.getPresharedKey());
                });
            }
//            else if (uuid.equals(Constants.WIFI_SERVER_IP_UUID)) {
//                result = wrapWrite("server IP", () -> {
//                    mediator.setServerIP(Wifi.ServerIP.parseFrom(value).getIpv4());
//                });
//            }
            else if (uuid.equals(Constants.TRANSFER_MEASUREMENT_FILES_UUID)) {
                result = wrapWrite("transfer files", () -> {
                    mediator.triggerFileTransfer(Measurements.RequestFiles.parseFrom(value).getMeasurementIdsList());
                });
            } else {
                Log.e("BLE", "char write request did not resolve");
                result = OperationResult.emptyFailure;
            }


            gattServer.sendResponse(device, requestId, (result.isSuccess() ? GATT_SUCCESS : GATT_FAILURE), offset, result.getResponse());


        }

        private final char[] hexArray = "0123456789ABCDEF".toCharArray();
        String bytesToString(byte[] bytes) {
            char[] hexChars = new char[bytes.length * 2];
            for ( int j = 0; j < bytes.length; j++ ) {
                int v = bytes[j] & 0xFF;
                hexChars[j * 2] = hexArray[v >>> 4];
                hexChars[j * 2 + 1] = hexArray[v & 0x0F];
            }
            return new String(hexChars);
        }

        @Override
        public void onCharacteristicReadRequest(BluetoothDevice device, int requestId, int offset, BluetoothGattCharacteristic characteristic) {
            UUID uuid = characteristic.getUuid();
            String charname = "";
            OperationResult result = null;
            byte[] bytes = null;
            if (uuid.equals(Constants.MEASUREMENT_STATUS_UUID)) {
                charname = "measurement status";
                result = getMeasurementStatus();
            }
            else if (uuid.equals(Constants.FETCH_MEASUREMENT_FILE_LISTING_UUID)) {
                charname = "measurement file listing";
                result = getFileListing();
            }
//            else if (uuid.equals(Constants.FETCH_MEASUREMENT_FILE_LISTING_UUID)) {
//                charname = "measurement file transferring";
//                bytes = fetchFileData("1");
//            }
            else if (uuid.equals(Constants.TRANSFER_STATUS_UUID)) {
                charname = "transfer status";
                result = getTransferStatus();
            }
            else if (uuid.equals(Constants.WIFI_SERVER_IP_UUID)) {
                charname = "fetch server ip";
                result = getServerIP();
            }
            else {
                gattServer.sendResponse(device, requestId, GATT_FAILURE, offset, new byte[] {});
                return;
            }

            Log.e("BLE", "char read request: " + charname);
            errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Char Read Request " + charname);
//            if(uuid.equals(Constants.FETCH_MEASUREMENT_FILE_LISTING_UUID)){
//                gattServer.sendResponse(device, requestId, GATT_SUCCESS, offset, bytes);
//            }
//            else {
            gattServer.sendResponse(device, requestId, (result.isSuccess() ? GATT_SUCCESS : GATT_FAILURE), offset, result.getResponse());
//           }
        }

        @Override
        public void onDescriptorWriteRequest(BluetoothDevice device, int requestId, BluetoothGattDescriptor descriptor, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value){
            super.onDescriptorWriteRequest(device, requestId, descriptor, preparedWrite, responseNeeded,
                    offset, value);

            descriptor.setValue(value);
            if (responseNeeded) {
                gattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS,
            /* No need to respond with offset */ 0,
            /* No need to respond with a value */ null);
            }

            UUID uuid = descriptor.getUuid();
            if(uuid.equals(Constants.MEASUREMENT_STATUS_NOTIFICATION_DESCRIPTOR_UUID)){
                Log.i("Descriptor", "The value has been requested");
                errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": The value has been requested");
            }
        }

        @Override
        public void onNotificationSent(BluetoothDevice device, int status){
            Log.i("Notification", "The status is: " + status);
            errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": The status is " + status);
        }
    }

    private class AdCallback extends AdvertiseCallback {
        private static final String TAG = "Athena AdCallback";

        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.i(TAG, "Advertising start - Success");
            errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Advertisement start - Success");
        }

        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            String reason = "?";
            switch (errorCode) {
                case ADVERTISE_FAILED_ALREADY_STARTED:
                    reason = "already started";
                    break;
                case ADVERTISE_FAILED_DATA_TOO_LARGE:
                    reason = "data too large";
                    break;
                case ADVERTISE_FAILED_FEATURE_UNSUPPORTED:
                    reason = "feature unsupported";
                    break;
                case ADVERTISE_FAILED_INTERNAL_ERROR:
                    reason = "internal error";
                    break;
                case ADVERTISE_FAILED_TOO_MANY_ADVERTISERS:
                    reason = "too many advertisers";
                    break;
            }
            Log.e(TAG, "Advertise failure: " + reason);
            errorLogger.appendLog(dirPath, "\n" + System.currentTimeMillis() + ": Advertisement failure - " + reason);
        }
    }

    private BluetoothGattService makeGattService() {
        BluetoothGattService service = new BluetoothGattService(Constants.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY);

        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.WIFI_CREDS_UUID, PROPERTY_WRITE, PERMISSION_WRITE));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.MEASUREMENT_TRIGGER_UUID, PROPERTY_WRITE, PERMISSION_WRITE));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.REQUEST_WIFI_POWER_UUID, PROPERTY_WRITE, PERMISSION_WRITE));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.FETCH_MEASUREMENT_FILE_LISTING_UUID, PROPERTY_READ, PERMISSION_READ));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.TRANSFER_MEASUREMENT_FILES_UUID, PROPERTY_WRITE, PERMISSION_WRITE));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.TRANSFER_STATUS_UUID, PROPERTY_READ, PERMISSION_READ));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.DELETE_MEASUREMENT_FILE_UUID, PROPERTY_WRITE, PERMISSION_WRITE));
        service.addCharacteristic(new BluetoothGattCharacteristic(Constants.WIFI_SERVER_IP_UUID, PROPERTY_READ, PERMISSION_READ));

//        measurementTriggerCharacteristic =
//                new BluetoothGattCharacteristic(Constants.MEASUREMENT_TRIGGER_UUID, PROPERTY_WRITE | PROPERTY_READ | PROPERTY_NOTIFY, PERMISSION_READ | PERMISSION_WRITE);
//        BluetoothGattDescriptor measurementDescriptor = new BluetoothGattDescriptor(Constants.MEASUREMENT_TRIGGER_NOTIFICATION_DESCRIPTOR_UUID, BluetoothGattDescriptor.PERMISSION_WRITE);
//        measurementDescriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
//        measurementTriggerCharacteristic.addDescriptor(measurementDescriptor);
//        service.addCharacteristic(measurementTriggerCharacteristic);
        /* ----------------------------------------------------------------------------------------------------------------------------- */

        measurementStatusCharacteristic =
                new BluetoothGattCharacteristic(Constants.MEASUREMENT_STATUS_UUID, PROPERTY_NOTIFY, PERMISSION_READ);
        measurementStatusCharacteristic.addDescriptor(getClientCharacteristicConfigurationDescriptor());
        service.addCharacteristic(measurementStatusCharacteristic);

        return service;
    }

    public static BluetoothGattDescriptor getClientCharacteristicConfigurationDescriptor() {
        BluetoothGattDescriptor descriptor = new BluetoothGattDescriptor(
                Constants.MEASUREMENT_STATUS_NOTIFICATION_DESCRIPTOR_UUID,
                (BluetoothGattDescriptor.PERMISSION_READ | BluetoothGattDescriptor.PERMISSION_WRITE));
        descriptor.setValue(new byte[]{0, 0});
        return descriptor;
    }
}
