package com.jci.athena.sensor.sensor;

import android.util.Log;

import com.jci.athena.sensor.Mediator;

/**
 * Concrete Sensor Handler
 */

public class SensorHandler implements ISensorHandler {
    private final Mediator mediator;
    private String captureId;

    public SensorHandler(Mediator mediator) {
        this.mediator = mediator;
    }

    public void setCaptureId(String captureId) {
        this.captureId = captureId;
    }

    public void handleData(byte[] bytes) {
//        mediator.saveDataStream(captureId, bytes);
        Log.i("CaptureId: ", captureId);
        Log.i("Timestamp: ", System.currentTimeMillis() + "");
        Log.i("Byte length: ", Integer.toString(bytes.length));
//        String[] nums = new String[bytes.length];
//        for(int i = 0; i < bytes.length; i++)
//            nums[i] = Byte.toString(bytes[i]);
//        Log.i("Sensor Handler", "got data: [ " + TextUtils.join(", ", nums) + " ]");
    }
}
